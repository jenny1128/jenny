package com.xxgl.sy.activity;

import com.xxgl.sy.dao.MyDBHelper;

import com.xxgl.lxx.R;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterActivity extends MyActivity implements View.OnClickListener{ 
	
	private MyDBHelper dbHelper;
	Button btn_Register=null;
	EditText mEtRegisteractivityUsername=null;
	EditText mEtRegisteractivityPassword2=null;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{ 
		super.onCreate(savedInstanceState); 
	    setContentView(R.layout.activity_register); 
	
	    dbHelper = new MyDBHelper(this); 
	    btn_Register =(Button)findViewById(R.id.bt_register);
	    mEtRegisteractivityUsername=(EditText)findViewById(R.id.et_registeractivity_username);
	    mEtRegisteractivityPassword2=(EditText)findViewById(R.id.et_registeractivity_password2);
	
	
	    btn_Register.setOnClickListener(new OnClickListener() {  
		@Override
		public void onClick(View v) {
	                //��ȡ�û�������û��������롢��֤��
	                String username = mEtRegisteractivityUsername.getText().toString().trim();
	                String password = mEtRegisteractivityPassword2.getText().toString().trim();
	                if (!TextUtils.isEmpty(username) && !TextUtils.isEmpty(password)) {
	                        //���û�����������뵽���ݿ���
	                    	dbHelper.add(username, password);
	                    	Toast.makeText(RegisterActivity.this, "ע��ɹ�", Toast.LENGTH_SHORT).show();
	                        Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
	                        startActivity(intent);
	                        finish();
	                    }
	                else {
	                    Toast.makeText(RegisterActivity.this, "δ������Ϣ��ע��ʧ��", Toast.LENGTH_SHORT).show();
	                }
	        }
	    });
     }

	@Override
	public void onClick(View v) {
		// TODO �Զ����ɵķ������
		
	}
}

	
