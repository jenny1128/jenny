package com.xxgl.sy.activity;

import java.util.ArrayList;
import java.util.List;
import com.xxgl.lxx.R;
import com.xxgl.sy.dao.ExpandAdapter;
import com.xxgl.sy.dao.ItemsDao;
import com.xxgl.sy.dateop.DateOp;

import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ExpandableListView;
import android.widget.Toast;
import android.widget.ExpandableListView.OnChildClickListener;

public class BudgetDetailActivity extends MyActivity  implements View.OnClickListener{
	
	EditText startdate = null;
	EditText enddate = null;
	ExpandableListView expandableListView = null;
	// ExpandAdapter adapter=null;
	List list = new ArrayList();
	List findresult = new ArrayList();
	String currentdate;
	String startTime;
	String endTime;
	Button ok = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_budget_detail);
		
    expandableListView = (ExpandableListView) findViewById(R.id.listBudget);
    ok=(Button) findViewById(R.id.okb);
		
		startdate = (EditText) findViewById(R.id.startdate);
		enddate = (EditText) findViewById(R.id.enddate);	
		
        currentdate=DateOp.getCurrentMonth();
		// 鍒濆锟�?
		startdate.setText(currentdate);
		enddate.setText(currentdate);

		// 榛樿鏄剧ず棰勭畻鏄庣粏
		list = new ItemsDao(BudgetDetailActivity.this).findsome(1, currentdate,currentdate);

		// 鍒ゆ柇鍒楄〃鏄惁涓虹┖
		if (list == null || list.size() == 0) {
			expandableListView.setVisibility(View.VISIBLE);
			
		} else {
			
			expandableListView.setVisibility(View.VISIBLE);
			final ExpandAdapter adapter = new ExpandAdapter(BudgetDetailActivity.this, list);
			expandableListView.setAdapter(adapter);

			// 璁剧疆item鐐瑰嚮鐨勭洃鍚櫒
			expandableListView.setOnChildClickListener(new OnChildClickListener() {

						@Override
						public boolean onChildClick(ExpandableListView parent,
								View v, int groupPosition, int childPosition,
								long id) {							
							Toast.makeText(
									BudgetDetailActivity.this,
									adapter.getChild(groupPosition,
											childPosition).toString(),
									Toast.LENGTH_SHORT).show();
							return false;
						}
					});
		}
		
		startdate.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				// dateInput.setInputType(InputType.TYPE_NULL);
				showDateDialog(startdate, 2, new MyActivity.Callback(){
					@Override
					void execute() {
					
					}
					
				});
			}
		  }
		);

		enddate.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				// dateInput.setInputType(InputType.TYPE_NULL);
				showDateDialog(enddate, 2, new MyActivity.Callback(){
					@Override
					void execute() {
					
					}
					
				});
			}
		});

		ok.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				startTime = startdate.getText().toString();
				endTime = enddate.getText().toString();
				findresult = new ItemsDao(BudgetDetailActivity.this)
				.findsome(1,startTime, endTime);
				checkDate();
			}
		});
		
		

	  }//oncreate
	

	public void checkDate()
	{
		if (startTime.compareTo(endTime) > 0) {
			
			expandableListView.setVisibility(View.INVISIBLE);
			Toast toast=Toast.makeText(BudgetDetailActivity.this,
					getString(R.string.kaishishijian), Toast.LENGTH_SHORT)	;
			toast.setGravity(Gravity.CENTER, 0, 0);
			toast.show();
		} else {

			if (findresult == null || findresult.size() == 0) {
				expandableListView.setVisibility(View.INVISIBLE);
				Toast toast=Toast.makeText(BudgetDetailActivity.this,
						getString(R.string.ciduanshijian), Toast.LENGTH_SHORT)	;
				toast.setGravity(Gravity.CENTER, 0, 0);
				toast.show();
				

			} else {
				expandableListView.setVisibility(View.VISIBLE);
				final ExpandAdapter adapter1 = new ExpandAdapter(
						BudgetDetailActivity.this, findresult);
				expandableListView.setAdapter(adapter1);
				adapter1.notifyDataSetChanged();
			}
		}
	}
	
	@Override  
    public boolean onKeyDown(int keyCode, KeyEvent event) {  
        if(keyCode == KeyEvent.KEYCODE_BACK){  
            return getParent().onKeyDown(keyCode, event);  
        }else{  
            return super.onKeyDown(keyCode, event);  
        }  
    }  

	
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.iv_back:
			finish();
			break;
		default:
			break;
		}
	}
}
