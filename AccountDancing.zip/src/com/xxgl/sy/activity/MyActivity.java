package com.xxgl.sy.activity;

import java.util.Calendar;

import android.app.Activity;
import android.app.Dialog;
import android.view.View;
import android.view.ViewGroup;
import android.widget.DatePicker;
import android.widget.EditText;

public class MyActivity extends Activity{
	protected void showDateDialog(EditText date, int showStyle, Callback callback) {
		final Calendar cal = Calendar.getInstance();
		Dialog mDialog = new MyDatePickerDialog(MyActivity.this,
				date, showStyle,callback, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH));

		mDialog.show();
		DatePicker dp = findDatePicker((ViewGroup) mDialog.getWindow().getDecorView());
		if (dp != null) {
			switch (showStyle) {
			case 3:
				break;
			case 2:
				((ViewGroup) ((ViewGroup) dp.getChildAt(0)).getChildAt(0)).getChildAt(2).setVisibility(View.GONE);
				break;
			case 1:
				((ViewGroup) ((ViewGroup) dp.getChildAt(0)).getChildAt(0)).getChildAt(2).setVisibility(View.GONE);
				((ViewGroup) ((ViewGroup) dp.getChildAt(0)).getChildAt(0)).getChildAt(1).setVisibility(View.GONE);
				break;

			default:
				break;
			}
		}
		
	}
	
	protected void showDateDialog(EditText date, Callback callback) {
		showDateDialog(date, 3, callback);
	}

	private DatePicker findDatePicker(ViewGroup group) {
		if (group != null) {
			for (int i = 0, j = group.getChildCount(); i < j; i++) {
				View child = group.getChildAt(i);
				if (child instanceof DatePicker) {
					return (DatePicker) child;
				} else if (child instanceof ViewGroup) {
					DatePicker result = findDatePicker((ViewGroup) child);
					if (result != null)
						return result;
				}
			}
		}
		return null;
	}
	
	public abstract class Callback {
		abstract void execute();
	}

}
