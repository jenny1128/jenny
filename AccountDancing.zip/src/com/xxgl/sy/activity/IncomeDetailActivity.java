package com.xxgl.sy.activity;

import java.util.ArrayList;
import java.util.List;
import com.xxgl.lxx.R;
import com.xxgl.sy.dao.ExpandAdapter;
import com.xxgl.sy.dao.IncomeDao;
import com.xxgl.sy.dateop.DateOp;

import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ExpandableListView;
import android.widget.Toast;
import android.widget.ExpandableListView.OnChildClickListener;

public class IncomeDetailActivity extends MyActivity implements View.OnClickListener{

	
	EditText startdate = null;
	EditText enddate = null;
	ExpandableListView expandableListView = null;
	// ExpandAdapter adapter=null;
	List list = new ArrayList();// list为跳转到此页面，默认显示的预算纪律列�?
	List findresult = new ArrayList();// 用户选择之后的结果列�?
	String currentdate;
	String startTime;
	String endTime;
	Button ok = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_income_detail);

		expandableListView = (ExpandableListView) findViewById(R.id.listIncome);
		ok = (Button) findViewById(R.id.oki);

		startdate = (EditText) findViewById(R.id.startdate);
		enddate = (EditText) findViewById(R.id.enddate);
		currentdate = DateOp.getCurrentDate();
		// 初始�?
		startdate.setText(currentdate);
		enddate.setText(currentdate);

		// 默认显示预算明细
		list = new IncomeDao(IncomeDetailActivity.this).findsome(currentdate,
				currentdate);

		// 判断列表是否为空
		if (list == null || list.size() == 0) {
			expandableListView.setVisibility(View.VISIBLE);

		} else {

			expandableListView.setVisibility(View.VISIBLE);
			final ExpandAdapter adapter = new ExpandAdapter(
					IncomeDetailActivity.this, list);
			expandableListView.setAdapter(adapter);

			// 设置item点击的监听器
			expandableListView
					.setOnChildClickListener(new OnChildClickListener() {

						@Override
						public boolean onChildClick(ExpandableListView parent,
								View v, int groupPosition, int childPosition,
								long id) {
							Toast.makeText(
									IncomeDetailActivity.this,
									adapter.getChild(groupPosition,
											childPosition).toString(),
									Toast.LENGTH_SHORT).show();
							return false;
						}
					});
		}

		startdate.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				// dateInput.setInputType(InputType.TYPE_NULL);
				showDateDialog(startdate, new MyActivity.Callback(){
					@Override
					void execute() {
					
					}
					
				});
			}
		});

		enddate.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				// dateInput.setInputType(InputType.TYPE_NULL);
				showDateDialog(enddate, new MyActivity.Callback(){
					@Override
					void execute() {
					
					}
					
				});
			}
		});

		ok.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				startTime = startdate.getText().toString();
				endTime = enddate.getText().toString();
				findresult = new IncomeDao(IncomeDetailActivity.this).findsome(
						 startTime, endTime);
				checkDate();
			}
		});

	}// oncreate


	public void checkDate() {
		if (startTime.compareTo(endTime) > 0) {

			expandableListView.setVisibility(View.INVISIBLE);
			Toast toast = Toast.makeText(IncomeDetailActivity.this,
					getString(R.string.kaishishijian), Toast.LENGTH_SHORT);
			toast.setGravity(Gravity.CENTER, 0, 0);
			toast.show();
		} else {

			if (findresult == null || findresult.size() == 0) {
				expandableListView.setVisibility(View.INVISIBLE);
				Toast toast = Toast.makeText(IncomeDetailActivity.this,
						getString(R.string.ciduanshijian), Toast.LENGTH_SHORT);
				toast.setGravity(Gravity.CENTER, 0, 0);
				toast.show();

			} else {
				expandableListView.setVisibility(View.VISIBLE);
				final ExpandAdapter adapter1 = new ExpandAdapter(
						IncomeDetailActivity.this, findresult);
				expandableListView.setAdapter(adapter1);
				adapter1.notifyDataSetChanged();
			}
		}
	}
	
	@Override  
    public boolean onKeyDown(int keyCode, KeyEvent event) {  
        if(keyCode == KeyEvent.KEYCODE_BACK){  
            return getParent().onKeyDown(keyCode, event);  
        }else{  
            return super.onKeyDown(keyCode, event);  
        }  
    }  
	
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.iv_back:
			finish();
			break;
		default:
			break;
		}
	}

}
