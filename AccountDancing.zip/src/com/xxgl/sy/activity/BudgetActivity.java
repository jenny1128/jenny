package com.xxgl.sy.activity;


import com.xxgl.lxx.R;
import com.xxgl.sy.bean.Items;
import com.xxgl.sy.dao.ItemsDao;
import com.xxgl.sy.dateop.DateOp;

import android.os.Bundle;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class BudgetActivity extends MyActivity implements View.OnClickListener{
	
	EditText dateInput=null;
	EditText foodET=null;
	EditText clothesET=null;
	EditText cosmeticET=null;
	EditText transportET=null;
	EditText communicateET=null;
	EditText leisureET=null;
	EditText othersET=null;
	EditText educationET=null;
	Button budgetSave=null;
	Button budgetCancel=null;
	String currentDate;
	
	ItemsDao itemsDao=new ItemsDao(BudgetActivity.this);
	
	
	//澹版槑涓嫭锟�?鏃犱簩鐨勬爣璇嗭紝浣滀负瑕佹樉绀篋atePicker鐨凞ialog鐨処D
	static final int ALTER_DIALOG_ID=1;	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_budget);		
		
		
		dateInput=(EditText) findViewById(R.id.date);
		foodET=(EditText) findViewById(R.id.food);
		clothesET=(EditText) findViewById(R.id.clothes);
		cosmeticET=(EditText) findViewById(R.id.cosmetic);
		transportET=(EditText) findViewById(R.id.transport);
		communicateET=(EditText) findViewById(R.id.communicate);
		leisureET=(EditText) findViewById(R.id.leisure);
		othersET=(EditText) findViewById(R.id.others);
		educationET=(EditText) findViewById(R.id.education);
		budgetSave=(Button) findViewById(R.id.budgetSave);
		budgetCancel=(Button) findViewById(R.id.budgetCancel);
		currentDate=DateOp.getCurrentMonth();
		dateInput.setText(currentDate);

		if(itemsDao.findBudgetSameDate(currentDate)){
			showDialog(ALTER_DIALOG_ID);
		}
    	
		dateInput.setOnClickListener(new OnClickListener() { //瀵规棩鏈熻緭鍏ユ鐨勪簨浠剁粦锟�?
			public void onClick(View v) {
				showDateDialog(dateInput, 2, new MyActivity.Callback(){
					@Override
					void execute() {
						if(itemsDao.findBudgetSameDate(dateInput.getText().toString()))
						{
							Toast.makeText(BudgetActivity.this, dateInput.getText().toString(), Toast.LENGTH_SHORT).show();
						    showDialog(ALTER_DIALOG_ID);
						}
						else{
							foodET.setText("");
		            		clothesET.setText("");
		            		cosmeticET.setText("");
		            		transportET.setText("");
		            		communicateET.setText("");
		            		leisureET.setText("");
		            		educationET.setText("");
		            		othersET.setText("");
						}
					}
				});
			}
		});
		budgetSave.setOnClickListener(new OnClickListener() {  //淇濆瓨鎸夐挳鐨勫锟�?
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Items item = new Items();
				item.setDate(dateInput.getText().toString());
				String foodStr = foodET.getText().toString();
				String clothesStr = clothesET.getText().toString();
				String cosmeticStr = cosmeticET.getText().toString();
				String communicateStr = communicateET.getText().toString();
				String transportStr = transportET.getText().toString();
				String educationStr = educationET.getText().toString();
				String othersStr = othersET.getText().toString();
				String leisureStr = leisureET.getText().toString();
				// String foodStr = foodET.getText().toString();
				item.setFood(Float.parseFloat((foodStr == null || foodStr
						.length() == 0) ? "0" : foodStr));
				item.setClothes(Float
						.parseFloat((clothesStr == null || clothesStr.length() == 0) ? "0"
								: clothesStr));
				item.setCosmetic(Float
						.parseFloat((cosmeticStr == null || cosmeticStr
								.length() == 0) ? "0" : cosmeticStr));
				item.setCommunicate(Float
						.parseFloat((communicateStr == null || communicateStr
								.length() == 0) ? "0" : communicateStr));
				item.setTransport(Float
						.parseFloat((transportStr == null || transportStr
								.length() == 0) ? "0" : transportStr));
				item.setLeisure(Float
						.parseFloat((leisureStr == null || leisureStr.length() == 0) ? "0"
								: leisureStr));
				item.setEducation(Float
						.parseFloat((educationStr == null || educationStr
								.length() == 0) ? "0" : educationStr));
				item.setOthers(Float.parseFloat((othersStr == null || othersStr
						.length() == 0) ? "0" : othersStr));
				item.setType(1);
				item.setSum();
				if (item.getSum() == 0) {
					Toast toast = Toast.makeText(getApplicationContext(),
							getString(R.string.gexiangbunnegwei), Toast.LENGTH_LONG);
					toast.show();
				} else {
					if (!itemsDao.findBudgetSameDate(item.getDate()))
						itemsDao.add(item);
					else
						itemsDao.update(item, item.getDate(), 1);

					Intent intent = new Intent();
					intent.setClass(BudgetActivity.this, MainActivity.class);
					startActivity(intent);
				}

			}
		});
		
		budgetCancel.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent intent = new Intent();
				intent.setClass(BudgetActivity.this, MainActivity.class);
				startActivity(intent);
			} });
	}
	/**
	 * 褰揂ctivity璋冪敤showDialog鍑芥暟鏃朵細瑙﹀彂璇ュ嚱鏁扮殑璋冪敤锟�?
	 */
	@Override
	protected Dialog onCreateDialog(int id) {
		
		switch (id) {
		
		case ALTER_DIALOG_ID:
		    return new  AlertDialog.Builder(this).   
	                setTitle(getString(R.string.tishi)).   
	                setMessage(getString(R.string.yusuanyijingcunzai)).   
	                setIcon(R.drawable.ic_launcher).setCancelable(false).
	                setPositiveButton(getString(R.string.queding),
	                		new DialogInterface.OnClickListener() {   
	                @Override   
	                    public void onClick(DialogInterface dialog, int which) {   
	                        // TODO Auto-generated method stub   
	                	dismissDialog(ALTER_DIALOG_ID);
	                    Items budget=itemsDao.search(dateInput.getText().toString(),1);
	            		foodET.setText(budget.getFood()+"");
	            		clothesET.setText(budget.getClothes()+"");
	            		cosmeticET.setText(budget.getCosmetic()+"");
	            		transportET.setText(budget.getTransport()+"");
	            		communicateET.setText(budget.getCommunicate()+"");
	            		leisureET.setText(budget.getLeisure()+"");
	            		educationET.setText(budget.getEducation()+"");
	            		othersET.setText(budget.getOthers()+"");
	            		budgetSave.setText(getString(R.string.querenxiugai));
	                       		                    	
	                    }   
	                }).setNeutralButton(getString(R.string.chongxuanriqi), new DialogInterface.OnClickListener() {   
	                       
	                    @Override   
	                    public void onClick(DialogInterface dialog, int which) {   
	                        // TODO Auto-generated method stub    
	                    	dismissDialog(ALTER_DIALOG_ID);
	                    	showDateDialog(dateInput,2, new MyActivity.Callback(){
	        					@Override
	        					void execute() {
	        						if(itemsDao.findBudgetSameDate(dateInput.getText().toString()))
	        						{
	        						    showDialog(ALTER_DIALOG_ID);
	        						}
	        						else{
	        							foodET.setText("");
	        		            		clothesET.setText("");
	        		            		cosmeticET.setText("");
	        		            		transportET.setText("");
	        		            		communicateET.setText("");
	        		            		leisureET.setText("");
	        		            		educationET.setText("");
	        		            		othersET.setText("");
	        						}
	        					}
	        				});
	                    }    
	                }).setNegativeButton(getString(R.string.fanhui), new DialogInterface.OnClickListener() {   
	                       
	                    @Override   
	                    public void onClick(DialogInterface dialog, int which) {   
	                        // TODO Auto-generated method stub    
	                    	dismissDialog(ALTER_DIALOG_ID);
	        						Intent intent = new Intent();
	        						intent.setClass(BudgetActivity.this, MainActivity.class);
	        						startActivity(intent);
	                    }    
	                }). create();   
		}
		return null;
	}
	
	

	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.iv_back:
			finish();
			break;
		default:
			break;
		}
	}


}