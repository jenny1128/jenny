package com.xxgl.sy.activity;

import com.xxgl.lxx.R;
import com.xxgl.sy.bean.Income;
import com.xxgl.sy.dao.IncomeDao;
import com.xxgl.sy.dateop.DateOp;

import android.os.Bundle;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class IncomeActivity extends MyActivity implements View.OnClickListener{
	
	EditText dateInput=null;
	EditText salaryET=null;
	EditText parttime_jobET=null;
	EditText subsidyET=null;
	EditText otherincomeET=null;
	Button incomeSave=null;
	Button incomeCancel=null;
	TextView tishi=null;
	IncomeDao  incomeDao = new IncomeDao(IncomeActivity.this);
	static final int ALTER_DIALOG_ID=1;	
	String currentDate;
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);  
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_income);
//		 incomeDao = new IncomeDao(IncomeActivity.this);//获得数据库操作实�?
		
		dateInput=(EditText) findViewById(R.id.date);
		salaryET=(EditText) findViewById(R.id.salary);
		parttime_jobET=(EditText) findViewById(R.id.parttime_job);
		subsidyET=(EditText) findViewById(R.id.subsidy);
		otherincomeET=(EditText) findViewById(R.id.otherincome);
		
		incomeSave=(Button) findViewById(R.id.IncomeSave);
		incomeCancel=(Button) findViewById(R.id.IncomeCancel);
		tishi=(TextView) findViewById(R.id.tishi);		
		currentDate=DateOp.getCurrentDate();
		
	   
		dateInput.setText(currentDate);
		
		if(incomeDao.findSameDate(currentDate)) showDialog(ALTER_DIALOG_ID);
		
		dateInput.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				showDateDialog(dateInput,new MyActivity.Callback(){
					@Override
					void execute() {
						if(incomeDao.findSameDate(dateInput.getText().toString()))
						    showDialog(ALTER_DIALOG_ID);
						else{
    						salaryET.setText("");
		            		parttime_jobET.setText("");
		            		subsidyET.setText("");
		            		otherincomeET.setText("");	}
					}
					
				});
			}
		});
		

		incomeSave.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Income income = new Income();

				income.setDate(dateInput.getText().toString());
				String salaryStr = salaryET.getText().toString();
				String parttime_jobStr = parttime_jobET.getText().toString();
				String subsidyStr = subsidyET.getText().toString();
				String otherincomeStr = otherincomeET.getText().toString();

				income.setSalary(Float.parseFloat((salaryStr == null || salaryStr.length() == 0) ? "0": salaryStr));
				income.setParttime_job(Float.parseFloat((parttime_jobStr == null || parttime_jobStr.length() == 0) ? "0" : parttime_jobStr));
				income.setSubsidy(Float.parseFloat((subsidyStr == null || subsidyStr.length() == 0) ? "0": subsidyStr));
				income.setOtherincome(Float.parseFloat((otherincomeStr == null || otherincomeStr.length() == 0) ? "0" : otherincomeStr));
				income.setSum();
				
				if (income.getSum() == 0) {
					Toast toast = Toast.makeText(getApplicationContext(),
							getString(R.string.gexiangbunnegwei), Toast.LENGTH_LONG);
					toast.show();
				} else {
					if (incomeDao.findSameDate(dateInput.getText().toString())) {
						incomeDao.update(income, currentDate);
					} else
						incomeDao.add(income);
					Intent intent = new Intent();
					intent.setClass(IncomeActivity.this, MainActivity.class);
					startActivity(intent);
				}
			}
		});
		
		
		
		incomeCancel.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				
				
				Intent intent = new Intent();
				intent.setClass(IncomeActivity.this, MainActivity.class);
				
				startActivity(intent);
			} });
		
	}
	
	

		/**
		 * 当Activity调用showDialog函数时会触发该函数的调用�?
		 */
		@Override
		protected Dialog onCreateDialog(int id) {
			switch (id) {
			
			case ALTER_DIALOG_ID:
			    return new  AlertDialog.Builder(this).   
		                setTitle(getString(R.string.tishi)).   
		                setMessage(getString(R.string.xiaofeiyijingcunzai)).   
		                setIcon(R.drawable.ic_launcher). setCancelable(false).  
		                setPositiveButton(getString(R.string.queding), new DialogInterface.OnClickListener() {   
		                @Override   
		                    public void onClick(DialogInterface dialog, int which) {   
		                        // TODO Auto-generated method stub   
		                	dismissDialog(ALTER_DIALOG_ID);
		                    Income income=incomeDao.search(dateInput.getText().toString()); 
		                    Toast.makeText(IncomeActivity.this, income.getSalary()+"", 
		                    		Toast.LENGTH_SHORT).show();
		                    salaryET.setText(income.getSalary()+"");
		            		parttime_jobET.setText(income.getParttime_job()+"");
		            		subsidyET.setText(income.getSubsidy()+"");
		            		otherincomeET.setText(income.getOtherincome()+"");	
		            		Toast.makeText(IncomeActivity.this, income.getSalary()+"", 
		            				Toast.LENGTH_SHORT).show();
		            		incomeSave.setText(getString(R.string.querenxiugai));
		                    }   
		                }).   
		                setNeutralButton(getString(R.string.chongxuanriqi), new DialogInterface.OnClickListener() {   
		                    @Override   
		                    public void onClick(DialogInterface dialog, int which) {   
		                        // TODO Auto-generated method stub    
		                    	dismissDialog(ALTER_DIALOG_ID);
		                    	showDateDialog(dateInput,new MyActivity.Callback(){
		        					@Override
		        					void execute() {
		        						if(incomeDao.findSameDate(dateInput.getText().toString()))
		        						    showDialog(ALTER_DIALOG_ID);
		        						else{
		        						salaryET.setText("");
		    		            		parttime_jobET.setText("");
		    		            		subsidyET.setText("");
		    		            		otherincomeET.setText("");	}
		        					}
		        					
		        				});
		                    }   
		                }).setNegativeButton(getString(R.string.fanhui), new DialogInterface.OnClickListener() {   
		                       
		                    @Override   
		                    public void onClick(DialogInterface dialog, int which) {   
		                        // TODO Auto-generated method stub    
		                    	dismissDialog(ALTER_DIALOG_ID);
		        						Intent intent = new Intent();
		        						intent.setClass(IncomeActivity.this, MainActivity.class);
		        						startActivity(intent);
		                    }    
		                }). create();   
			}
			return null;
		}


//	@Override  
//	public boolean onKeyDown(int keyCode, KeyEvent event) {  
//		if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {  
//			removeDialog(ALTER_DIALOG_ID);
//			Intent intent = new Intent();
//			intent.setClass(IncomeActivity.this, MenuActivity.class);
//			startActivity(intent);
//			return true;  
//		} else  
//			return super.onKeyDown(keyCode, event);  
//	}  
		
		public void onClick(View v) {
			// TODO Auto-generated method stub
			switch (v.getId()) {
			case R.id.iv_back:
				finish();
				break;
			default:
				break;
			}
		}

}
