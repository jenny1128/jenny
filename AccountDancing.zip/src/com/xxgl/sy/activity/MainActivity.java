package com.xxgl.sy.activity;

import com.xxgl.lxx.R;
import com.xxgl.sy.dao.ItemsDao;

import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity implements View.OnClickListener{
	
	Button budgetBtn=null;
	Button findbudgetBtn=null;
	Button incomeBtn=null;
	Button consumeBtn=null;
	Button listBtn=null;
	Button countBtn=null;
	Button loginBtn=null;
	
	Button btn_myinfo,btn_sysinfo;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_menu);
		 

		
		budgetBtn = (Button) findViewById(R.id.budget); //预算管理按钮
		incomeBtn = (Button) findViewById(R.id.income); //收入管理按钮
		consumeBtn = (Button) findViewById(R.id.consume); //支出管理按钮
		listBtn = (Button) findViewById(R.id.list);//各项明细
		loginBtn=(Button) findViewById(R.id.login);
		btn_myinfo= (Button) findViewById(R.id.btn_myinfo);
		btn_sysinfo= (Button) findViewById(R.id.btn_sysinfo);
		btn_myinfo.setOnClickListener(this);
		btn_sysinfo.setOnClickListener(this);
		

	    loginBtn.setOnClickListener(new OnClickListener() {
			
			public void onClick(View v) {
				Intent intent = new Intent();
				intent.setClass(MainActivity.this, LoginActivity.class);
				startActivity(intent);
			}
		});
		
		
		//跳转到添加预算页�?
		budgetBtn.setOnClickListener(new OnClickListener() {
			
			public void onClick(View v) {
				Intent intent = new Intent();
				intent.setClass(MainActivity.this, BudgetActivity.class);
				startActivity(intent);
			}
		});
		
		
		//跳转到收入页�?
		incomeBtn.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				/* 此处用Intent来实现Activity与Activity之间的跳�? */
				Intent intent = new Intent();
				intent.setClass(MainActivity.this, IncomeActivity.class);
				startActivity(intent);
			}
		});
		
		//跳转到消费页�?
		consumeBtn.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				/* 此处用Intent来实现Activity与Activity之间的跳�? */
				Intent intent = new Intent();
				intent.setClass(MainActivity.this, ConsumeActivity.class);
				startActivity(intent);
			}
		});
		
		//跳转到清单页�?
		listBtn.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				/* 此处用Intent来实现Activity与Activity之间的跳�? */
				Intent intent = new Intent();
				intent.setClass(MainActivity.this,MyDetailsActivity.class);
//				intent.setClass(MenuActivity.this,DetailsActivity.class);
				Bundle bundle=new Bundle();
				bundle.putInt("type", 2);
				intent.putExtras(bundle);
				startActivity(intent);
			}
		});

	}
	

	public void onClick(View v) {
		// TODO Auto-generated method stub
		
		switch (v.getId()) {
		case R.id.iv_back:
			finish();
			break;
		case R.id.btn_myinfo:
			Intent m = new Intent(MainActivity.this,MyInfoActivity.class);
			startActivity(m);
			break;
		case R.id.btn_sysinfo:
			Intent sys = new Intent(MainActivity.this,SystemInfoActivity.class);
			startActivity(sys);
			break;
		default:
			break;
		}
	}

}
