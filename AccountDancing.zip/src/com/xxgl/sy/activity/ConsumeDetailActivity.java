package com.xxgl.sy.activity;

import java.util.ArrayList;
import java.util.List;
import com.xxgl.lxx.R;
import com.xxgl.sy.dao.ExpandAdapter;
import com.xxgl.sy.dao.ItemsDao;
import com.xxgl.sy.dateop.DateOp;

import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ExpandableListView;
import android.widget.Toast;
import android.widget.ExpandableListView.OnChildClickListener;

public class ConsumeDetailActivity extends MyActivity implements View.OnClickListener{
	// 声明�?个独�?无二的标识，作为要显示DatePicker的Dialog的ID
	static final int DATE_DIALOG_ID0 = 0;
	static final int DATE_DIALOG_ID1 = 1;
	EditText startdate = null;
	EditText enddate = null;
	ExpandableListView expandableListView = null;
	// ExpandAdapter adapter=null;
	List list = new ArrayList();// list为跳转到此页面，默认显示的预算纪律列�?
	List findresult = new ArrayList();// 用户选择之后的结果列�?
	String currentdate;
	String startTime;
	String endTime;
	Button ok = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_consume_detail);

		expandableListView = (ExpandableListView) findViewById(R.id.listConsume);
		ok = (Button) findViewById(R.id.okc);

		startdate = (EditText) findViewById(R.id.startdate);
		enddate = (EditText) findViewById(R.id.enddate);
		currentdate = DateOp.getCurrentDate();
		// 初始�?
		startdate.setText(currentdate);
		enddate.setText(currentdate);

		// 默认显示预算明细
		list = new ItemsDao(ConsumeDetailActivity.this).findsome(2,
				currentdate, currentdate);

		// 判断列表是否为空
		if (list == null || list.size() == 0) {
			expandableListView.setVisibility(View.VISIBLE);

		} else {

			expandableListView.setVisibility(View.VISIBLE);
			final ExpandAdapter adapter = new ExpandAdapter(
					ConsumeDetailActivity.this, list);
			expandableListView.setAdapter(adapter);

			// 设置item点击的监听器
			expandableListView
					.setOnChildClickListener(new OnChildClickListener() {

						@Override
						public boolean onChildClick(ExpandableListView parent,
								View v, int groupPosition, int childPosition,
								long id) {
							Toast.makeText(
									ConsumeDetailActivity.this,
									adapter.getChild(groupPosition,
											childPosition).toString(),
									Toast.LENGTH_SHORT).show();
							return false;
						}
					});
		}

		startdate.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				// dateInput.setInputType(InputType.TYPE_NULL);
				showDateDialog(startdate, new MyActivity.Callback() {
					@Override
					void execute() {

					}

				});
			}
		});

		enddate.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				// dateInput.setInputType(InputType.TYPE_NULL);
				showDateDialog(enddate, new MyActivity.Callback() {
					@Override
					void execute() {

					}

				});
			}
		});

		ok.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				startTime = startdate.getText().toString();
				endTime = enddate.getText().toString();
				findresult = new ItemsDao(ConsumeDetailActivity.this).findsome(
						2, startTime, endTime);
				checkDate();
			}
		});

	}// oncreate

	// �?要定义弹出的DatePicker对话框的事件监听器：
//	private DatePickerDialog.OnDateSetListener mDateSetListener0 = new OnDateSetListener() {
//		public void onDateSet(DatePicker view, int year, int monthOfYear,
//				int dayOfMonth) {
//			mYear = year;
//			mMonth = monthOfYear;
//			mDay = dayOfMonth;
//			// 设置文本的内容：
//			startdate.setText(new StringBuilder()
//					.append(mYear)
//					.append("-")
//					.append((mMonth + 1) > 9 ? (mMonth + 1) : "0"
//							+ (mMonth + 1)).append("-")
//					.append(mDay > 9 ? mDay : "0" + mDay));
//		}
//	};
//
//	private DatePickerDialog.OnDateSetListener mDateSetListener1 = new OnDateSetListener() {
//		public void onDateSet(DatePicker view, int year, int monthOfYear,
//				int dayOfMonth) {
//			mYear = year;
//			mMonth = monthOfYear;
//			mDay = dayOfMonth;
//			// 设置文本的内容：
//			enddate.setText(new StringBuilder()
//					.append(mYear)
//					.append("-")
//					.append((mMonth + 1) > 9 ? (mMonth + 1) : "0"
//							+ (mMonth + 1)).append("-")
//					.append(mDay > 9 ? mDay : "0" + mDay));
//		}
//	};

	/**
	 * 当Activity调用showDialog函数时会触发该函数的调用�?
	 */

//	@Override
//	protected Dialog onCreateDialog(int id) {
//		switch (id) {
//		case DATE_DIALOG_ID0:
//			return new DatePickerDialog(this, mDateSetListener0, Calendar
//					.getInstance().get(Calendar.YEAR), Calendar.getInstance()
//					.get(Calendar.MONTH), Calendar.getInstance().get(
//					Calendar.DAY_OF_MONTH));
//		case DATE_DIALOG_ID1:
//			return new DatePickerDialog(this, mDateSetListener1, Calendar
//					.getInstance().get(Calendar.YEAR), Calendar.getInstance()
//					.get(Calendar.MONTH), Calendar.getInstance().get(
//					Calendar.DAY_OF_MONTH));
//
//		}
//		return null;
//	}


	public void checkDate() {
		if (startTime.compareTo(endTime) > 0) {

			expandableListView.setVisibility(View.INVISIBLE);
			Toast toast = Toast.makeText(ConsumeDetailActivity.this,
					getString(R.string.kaishishijian), Toast.LENGTH_SHORT);
			toast.setGravity(Gravity.CENTER, 0, 0);
			toast.show();
		} else {

			if (findresult == null || findresult.size() == 0) {
				expandableListView.setVisibility(View.INVISIBLE);
				Toast toast = Toast.makeText(ConsumeDetailActivity.this,
						getString(R.string.ciduanshijian), Toast.LENGTH_SHORT);
				toast.setGravity(Gravity.CENTER, 0, 0);
				toast.show();

			} else {
				expandableListView.setVisibility(View.VISIBLE);
				final ExpandAdapter adapter1 = new ExpandAdapter(
						ConsumeDetailActivity.this, findresult);
				expandableListView.setAdapter(adapter1);
				adapter1.notifyDataSetChanged();
			}
		}
	}
	@Override  
    public boolean onKeyDown(int keyCode, KeyEvent event) {  
        if(keyCode == KeyEvent.KEYCODE_BACK){  
            return getParent().onKeyDown(keyCode, event);  
        }else{  
            return super.onKeyDown(keyCode, event);  
        }  
    }  


	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.iv_back:
			finish();
			break;
		default:
			break;
		}
	}
}
