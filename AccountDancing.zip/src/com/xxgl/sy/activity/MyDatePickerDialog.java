package com.xxgl.sy.activity;

import com.xxgl.sy.activity.MyActivity.Callback;

import android.app.DatePickerDialog;
import android.content.Context;
import android.widget.DatePicker;
import android.widget.EditText;

public class MyDatePickerDialog extends DatePickerDialog{

	public MyDatePickerDialog(Context context, final EditText date, final int showStyle, final Callback callback,
			int year, int monthOfYear, int dayOfMonth) {
		
		super(context, new OnDateSetListener() {
			public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
				StringBuilder sb = new StringBuilder();				
				switch (showStyle) {
				case 3:
					sb.append(year).append("-").append((monthOfYear + 1) > 9 ? (monthOfYear + 1) : "0" + (monthOfYear + 1)).append("-").append(dayOfMonth > 9 ? dayOfMonth : "0" + dayOfMonth);
					break;
				case 2:
					sb.append(year).append("-").append((monthOfYear + 1) > 9 ? (monthOfYear + 1) : "0" + (monthOfYear + 1));
					break;
				case 1:
					sb.append(year);
					break;

				default:
					break;
				}
								// 设置文本的内容：
				date.setText(sb.toString());
				if(callback != null){
					callback.execute();
				}
			}}, year, monthOfYear, dayOfMonth);
		// TODO Auto-generated constructor stub
		
	}

}
