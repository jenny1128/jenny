package com.xxgl.sy.activity;

import java.util.ArrayList;

import com.xxgl.lxx.R;
import com.xxgl.sy.bean.User;
import com.xxgl.sy.dao.MyDBHelper;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends MyActivity implements View.OnClickListener {
    
	MyDBHelper dbHelper;
    Button loginBtn=null;
	Button logonBtn=null;
    EditText username=null;
    EditText userpassword=null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_login);
        
        dbHelper = new MyDBHelper(this);
        loginBtn=(Button) findViewById(R.id.loginReg);
        logonBtn=(Button) findViewById(R.id.logon);
        username=(EditText)findViewById(R.id.usernameLog);
        userpassword=(EditText)findViewById(R.id.passwordLog);
        
     //���ע�ᰴť����ע��ҳ�� 
        logonBtn.setOnClickListener(new OnClickListener() {  
		@Override
		public void onClick(View v) {
			Intent intent = new Intent(LoginActivity.this,RegisterActivity.class);
	        startActivity(intent);
		}
    });


    //�����¼��ť 
        loginBtn.setOnClickListener(new OnClickListener() {  
		@Override
		public void onClick(View v) {

        String userName=username.getText().toString();
        String passWord=userpassword.getText().toString();
        if (!TextUtils.isEmpty(userName) && !TextUtils.isEmpty(passWord)) {
            ArrayList<User> data = dbHelper.getAllData();
            boolean match = false;
            for(int i=0;i<data.size();i++) {
                User user = data.get(i);
                if (userName.equals(user.getName()) && passWord.equals(user.getPassword())){
                    match = true;
                    break;
                }else{
                    match = false;
                }
            }
            if (match) {
                Toast.makeText(LoginActivity.this, "��¼�ɹ�", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(LoginActivity.this, Main2Activity.class);
                startActivity(intent);
                finish();//���ٴ�Activity
            }else {
                Toast.makeText(LoginActivity.this, "�û��������벻��ȷ������������", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(LoginActivity.this, "����������û���������", Toast.LENGTH_SHORT).show();
        }	
	}
    });
  }

	@Override
	public void onClick(View v) {
		// TODO �Զ����ɵķ������
		
	}
 }
