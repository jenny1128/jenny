package com.xxgl.sy.activity;

import com.xxgl.lxx.R;
import android.os.Bundle;
import android.os.Debug;
import android.app.Activity;
import android.app.ActivityGroup;
import android.content.Intent;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.TabHost.OnTabChangeListener;

public class MyDetailsActivity extends ActivityGroup {
	
	TabHost tabHost;
	TabHost.TabSpec spec = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState); 
		setContentView(R.layout.activity_details);
		tabHost = (TabHost) this.findViewById(R.id.mytabhost);
		tabHost.setup();
	    tabHost.setup(this.getLocalActivityManager());
//		tabHost.setBackgroundResource(R.drawable.background);
		// 修改默认的背景颜�?
		Intent budget = new Intent(this, BudgetDetailActivity.class);
		Intent consume = new Intent(this, ConsumeDetailActivity.class);
		Intent income = new Intent(this, IncomeDetailActivity.class);
		// 通过TabHost.TabSpec增加tab的一页，�?
		spec = tabHost.newTabSpec(getString(R.string.yusuanmingxi));
		// 通过setIndicator增加页的标签
		spec.setIndicator(createTabView(getString(R.string.yusuanmingxi)));
		// 通过setContent()增加标签事件
		spec.setContent(budget);
		tabHost.addTab(spec);

		spec = tabHost.newTabSpec(getString(R.string.xiaofeimingxi));
		spec.setIndicator(createTabView(getString(R.string.xiaofeimingxi)));// title
		spec.setContent(consume);
		tabHost.addTab(spec);

		spec = tabHost.newTabSpec(getString(R.string.shourumingxi));
		spec.setIndicator(createTabView(getString(R.string.shourumingxi)));// title
		spec.setContent(income);
		tabHost.addTab(spec);
		// tabHost.setCurrentTab(1);
		// 标签切换事件处理，setOnTabChangedListener
		tabHost.setOnTabChangedListener(new OnTabChangeListener() {
			public void onTabChanged(String tabId) {
				Activity activity = getLocalActivityManager().getActivity(tabId);
				if (activity != null) {
					activity.onWindowFocusChanged(true);
				}
			}
		});

	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
	}

	private View createTabView(String name) {

		LinearLayout linearLayout = new LinearLayout(this);
		linearLayout.setOrientation(LinearLayout.VERTICAL);
		linearLayout.setBackgroundColor(0xFFFFFF);
		
		TextView textView = new TextView(this);
		textView.setText(name);
		textView.setBackgroundResource(R.drawable.tab_bg);
		textView.setTextColor(Color.WHITE);
		textView.setTextSize(18.0f);
		textView.setGravity(Gravity.CENTER);
		ViewGroup.LayoutParams params = new ViewGroup.LayoutParams(
				ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
		linearLayout.addView(textView, params);
		
		return linearLayout;
	}

}
