package com.xxgl.sy.activity;

import com.xxgl.lxx.R;
import com.xxgl.sy.dao.ItemsDao;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.TextView;

public class SystemInfoActivity extends Activity implements View.OnClickListener{

	TextView tv_title;
	TextView first=null;

	float sum[]=new float[3];
	float left=0;//本月消费预算之差
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_sysinfo);
		ItemsDao itemsDao=new ItemsDao(SystemInfoActivity.this); //定义 数据库操作对�?
	    sum=itemsDao.findMonthData();//调用对象的findMonthData方法.返回�?个数组，数组第一项是预算统计，第二项是消费统计，第三项是按收入统�?
		float left=sum[0]-sum[1];//预算统计 - 消费统计  = �?         通过这种方式算出，有没有超过预算，或者超出多少了
		tv_title = (TextView) findViewById(R.id.tv_title);
		tv_title.setText("资产分析");
		first=(TextView) findViewById(R.id.first); //文本：提醒是否超过预�?
		showTips(left,sum);//将算出的left�? 设置显示出来
	}

	void showTips(float left,float a[]){
		float surplus=0;
		surplus=a[2]-a[1];
		if (a[0] != 0) {
			if (left >= 100) {
				first.setText(getString(R.string.shizhijinri) + a[2] 
						+ getString(R.string.yuanxiaofei) + a[1] + getString(R.string.yuanyunyu)
						+ surplus + getString(R.string.yuanmeichaochu));
			} else if (left < 100 && left >= 0) {
				
				if (left == 0 && a[0] != 0 && a[1] != 0)
					first.setText(getString(R.string.shizhijinri) + a[2] + getString(R.string.yuanxiaofei)
							+ a[1] +getString(R.string.yuanyunyu)
							+ surplus + getString(R.string.yidadaoyusuan));
				else
					first.setText(getString(R.string.shizhijinri)+ a[2] 
							+ getString(R.string.yuanxiaofei) + a[1] + getString(R.string.yuanyunyu)
							+ surplus + getString(R.string.buzu100));

			} else if (left < 0) {
				
				first.setText(getString(R.string.shizhijinri)+ a[2] + 
						getString(R.string.yuanxiaofei)
						+ a[1] + getString(R.string.yuanyunyu)
						+ surplus + getString(R.string.chaochuyusuan));
			}
		}
		else
		{
			first.setText(getString(R.string.shizhijinri)+ a[2] + getString(R.string.yuanxiaofei)
					+ a[1] + getString(R.string.yuanyunyu)
					+ surplus + getString(R.string.meitianjiayusuan));
		}
	}
	
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.iv_back:
			finish();
			break;
		default:
			break;
		}
	}
}
