package com.xxgl.sy.activity;

import java.util.Calendar;

import com.xxgl.lxx.R;
import com.xxgl.sy.bean.Income;
import com.xxgl.sy.bean.Items;
import com.xxgl.sy.dao.ItemsDao;
import com.xxgl.sy.dateop.DateOp;

import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.content.DialogInterface;
import android.content.Intent;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

public class ConsumeActivity extends MyActivity implements View.OnClickListener{

	EditText dateInput = null;
	EditText foodET = null;
	EditText clothesET = null;
	EditText cosmeticET = null;
	EditText transportET = null;
	EditText communicateET = null;
	EditText leisureET = null;
	EditText othersET = null;
	EditText educationET = null;
	Button consumeSave = null;
	Button consumeCancel = null;

	// 用来保存年月�?
	private int mYear;
	private int mMonth;
	private int mDay;

	// 声明�?个独�?无二的标识，作为要显示DatePicker的Dialog的ID
	static final int DATE_DIALOG_ID = 0;
	static final int ALTER_DIALOG_ID = 1;
	static final int DIALOG_MIN=2;	
	static final int DIALOG_NEAR=3;	
	static final int DIALOG_MAX=4;	
	static final int DIALOG_ZERO=5;	
	
	
    String currentDate;
	ItemsDao itemsDao = new ItemsDao(ConsumeActivity.this);

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState); 
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_consume);
        currentDate=DateOp.getCurrentDate();
		dateInput = (EditText) findViewById(R.id.date);
		foodET = (EditText) findViewById(R.id.food);
		clothesET = (EditText) findViewById(R.id.clothes);
		cosmeticET = (EditText) findViewById(R.id.cosmetic);
		transportET = (EditText) findViewById(R.id.transport);
		communicateET = (EditText) findViewById(R.id.communicate);
		leisureET = (EditText) findViewById(R.id.leisure);
		othersET = (EditText) findViewById(R.id.others);
		educationET = (EditText) findViewById(R.id.education);
		consumeSave = (Button) findViewById(R.id.ConsumeSave);
		consumeCancel = (Button) findViewById(R.id.ConsumeCancel);   		
		dateInput.setText(currentDate);	
		
		boolean DateIsSame=itemsDao.findConsumeSameDate(currentDate);
		if(DateIsSame) showDialog(ALTER_DIALOG_ID);
		
		
		dateInput.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				showDateDialog(dateInput,new MyActivity.Callback(){
					@Override
					void execute() {
						if(itemsDao.findConsumeSameDate(dateInput.getText().toString()))
						{  showDialog(ALTER_DIALOG_ID);}
						else{
							foodET.setText("");
		            		clothesET.setText("");
		            		cosmeticET.setText("");
		            		transportET.setText("");
		            		communicateET.setText("");
		            		leisureET.setText("");
		            		educationET.setText("");
		            		othersET.setText("");
		            		
						}
					}
					
				});
			}
		});



		consumeSave.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Items item = new Items();

				item.setDate(dateInput.getText().toString());
				String foodStr = foodET.getText().toString();
				String clothesStr = clothesET.getText().toString();
				String cosmeticStr = cosmeticET.getText().toString();
				String communicateStr = communicateET.getText().toString();
				String transportStr = transportET.getText().toString();
				String educationStr = educationET.getText().toString();
				String othersStr = othersET.getText().toString();
				String leisureStr = leisureET.getText().toString();
				// String foodStr = foodET.getText().toString();
				item.setFood(Float.parseFloat((foodStr == null || foodStr
						.length() == 0) ? "0" : foodStr));
				item.setClothes(Float
						.parseFloat((clothesStr == null || clothesStr.length() == 0) ? "0"
								: clothesStr));
				item.setCosmetic(Float
						.parseFloat((cosmeticStr == null || cosmeticStr
								.length() == 0) ? "0" : cosmeticStr));
				item.setCommunicate(Float
						.parseFloat((communicateStr == null || communicateStr
								.length() == 0) ? "0" : communicateStr));
				item.setTransport(Float
						.parseFloat((transportStr == null || transportStr
								.length() == 0) ? "0" : transportStr));
				item.setLeisure(Float
						.parseFloat((leisureStr == null || leisureStr.length() == 0) ? "0"
								: leisureStr));
				item.setEducation(Float
						.parseFloat((educationStr == null || educationStr
								.length() == 0) ? "0" : educationStr));
				item.setOthers(Float.parseFloat((othersStr == null || othersStr
						.length() == 0) ? "0" : othersStr));
				item.setType(2);
				item.setSum();
				
				if (item.getSum() == 0) {
					Toast toast = Toast.makeText(getApplicationContext(),
							getString(R.string.gexiangbunnegwei), Toast.LENGTH_LONG);
					toast.show();
				} else {
				if (!itemsDao.findConsumeSameDate(item.getDate()))
					itemsDao.add(item);
				else{
					itemsDao.update(item, item.getDate(), 2);}
				
			    float sum[]=itemsDao.findMonthData();
				float left=sum[0]-sum[1];
				
				
				if (left >=100) {
					showDialog(DIALOG_MIN);					
				} else if (left < 100 && left >= 0) {					
					if (left == 0&&sum[1]!=0&&sum[0]!=0)
						showDialog(DIALOG_ZERO);
					else
						showDialog(DIALOG_NEAR);
				} else if (left < 0) {
					showDialog(DIALOG_MAX);
				}
				Intent intent = new Intent();
				intent.setClass(ConsumeActivity.this, MainActivity.class);

				}
			}
		});

		consumeCancel.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent intent = new Intent();
				intent.setClass(ConsumeActivity.this, MainActivity.class);
				startActivity(intent);

			}
		});

	}

	/**
	 * 当Activity调用showDialog函数时会触发该函数的调用�?
	 */
	
	@Override
	protected Dialog onCreateDialog(int id) {
		switch (id) {
		
		case ALTER_DIALOG_ID:
			return new AlertDialog.Builder(this)
					.setTitle(getString(R.string.tishi))
					.setMessage(getString(R.string.xiaofeiyijingcunzai))
					.setIcon(R.drawable.ic_launcher).setCancelable(false)
					.setPositiveButton(getString(R.string.queding),
							new DialogInterface.OnClickListener() {
								@Override
								public void onClick(DialogInterface dialog,
										int which) {
									// TODO Auto-generated method stub
									dismissDialog(ALTER_DIALOG_ID);
									Items consume = itemsDao.search(dateInput
											.getText().toString(), 2);

									foodET.setText(consume.getFood() + "");
									clothesET.setText(consume.getClothes() + "");
									cosmeticET.setText(consume.getCosmetic()
											+ "");
									transportET.setText(consume.getTransport()
											+ "");
									communicateET.setText(consume
											.getCommunicate() + "");
									leisureET.setText(consume.getLeisure() + "");
									educationET.setText(consume.getEducation()
											+ "");
									othersET.setText(consume.getOthers() + "");
									consumeSave.setText(getString(R.string.querenxiugai));

								}
							})
					.setNeutralButton(getString(R.string.chongxuanriqi),
							new DialogInterface.OnClickListener() {

								@Override
								public void onClick(DialogInterface dialog,
										int which) {
									dismissDialog(ALTER_DIALOG_ID);
									// TODO Auto-generated method stub
									showDateDialog(dateInput,new MyActivity.Callback(){
										@Override
										void execute() {
											if(itemsDao.findConsumeSameDate(dateInput.getText().toString()))
											{    showDialog(ALTER_DIALOG_ID);}
											else{
												foodET.setText("");
							            		clothesET.setText("");
							            		cosmeticET.setText("");
							            		transportET.setText("");
							            		communicateET.setText("");
							            		leisureET.setText("");
							            		educationET.setText("");
							            		othersET.setText("");
											}
										}
									});
								}
							}).setNegativeButton(getString(R.string.fanhui), new DialogInterface.OnClickListener() {   
			                       
			                    @Override   
			                    public void onClick(DialogInterface dialog, int which) {   
			                        // TODO Auto-generated method stub    
			                    	dismissDialog(ALTER_DIALOG_ID);
			                    	
			        						Intent intent = new Intent();
			        						intent.setClass(ConsumeActivity.this, MainActivity.class);
			        						startActivity(intent);
			                    }    
			                }).create();
			
		case DIALOG_MIN:
			return new  AlertDialog.Builder(this).   
	                setTitle(getString(R.string.tishi)).   
	                setMessage(getString(R.string.yusuanmeichao)).   
	                setIcon(R.drawable.smile).setCancelable(false).   
	                setPositiveButton(getString(R.string.queding), new DialogInterface.OnClickListener() {   
	                @Override   
	                    public void onClick(DialogInterface dialog, int which) {   
	                        // TODO Auto-generated method stub         
	                	Intent intent = new Intent();
	    				intent.setClass(ConsumeActivity.this, MainActivity.class);
	    				startActivity(intent);
	                	
	                       		                    	
	                    }   
	                }).create();  
		
			
		case DIALOG_NEAR:
		    return new  AlertDialog.Builder(this).   
	                setTitle(getString(R.string.tishi)).   
	                setMessage(getString(R.string.yusuanshengyu100)).   
	                setIcon(R.drawable.tt).setCancelable(false).      
	                setPositiveButton(getString(R.string.queding), new DialogInterface.OnClickListener() {   
	                @Override   
	                    public void onClick(DialogInterface dialog, int which) {   
	                        // TODO Auto-generated method stub   	    
	                	Intent intent = new Intent();
	    				intent.setClass(ConsumeActivity.this, MainActivity.class);
	    				startActivity(intent);
	                       		                    	
	                    }   
	                }).setNegativeButton(getString(R.string.chakanxiangqing), new DialogInterface.OnClickListener() {   
	                       
	                    @Override   
	                    public void onClick(DialogInterface dialog, int which) {   
	                        // TODO Auto-generated method stub    
//	                    	Intent intent = new Intent();
//	        				intent.setClass(ConsumeActivity.this, ChartActivity.class);
//	        				startActivity(intent);
	                    	
	                    }   
	                }).create();   
		
		
	 case DIALOG_MAX:
	    return new  AlertDialog.Builder(this).   
                setTitle(getString(R.string.tishi)).setCancelable(false).      
                setMessage(getString(R.string.chaoguoyusuan)).   
                setIcon(R.drawable.cry).   
                setPositiveButton(getString(R.string.queding), new DialogInterface.OnClickListener() {   
                @Override   
                    public void onClick(DialogInterface dialog, int which) {   
                        // TODO Auto-generated method stub   	 
                	Intent intent = new Intent();
    				intent.setClass(ConsumeActivity.this, MainActivity.class);
    				startActivity(intent);
                       		                    	
                    }   
                }).setNegativeButton(getString(R.string.chakanxiangqing), new DialogInterface.OnClickListener() {   
                    
                 @Override   
                 public void onClick(DialogInterface dialog, int which) {   
                     // TODO Auto-generated method stub    
//                 	Intent intent = new Intent();
//     				intent.setClass(ConsumeActivity.this, ChartActivity.class);
//     				startActivity(intent);
                 	
                 }   
             }).create();   
	    
	 case DIALOG_ZERO:
			return new  AlertDialog.Builder(this).   
	                setTitle(getString(R.string.tishi)).   
	                setMessage(getString(R.string.zhichudadao)).   
	                setIcon(R.drawable.tt).setCancelable(false).      
	                setPositiveButton(getString(R.string.queding), new DialogInterface.OnClickListener() {   
	                @Override   
	                    public void onClick(DialogInterface dialog, int which) {   
	                        // TODO Auto-generated method stub         
	                	Intent intent = new Intent();
	    				intent.setClass(ConsumeActivity.this, MainActivity.class);
	    				startActivity(intent);
	                	
	                       		                    	
	                    }   
	                }).create();  
		
		
		
		}
		return null;
	}

	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.iv_back:
			finish();
			break;
		default:
			break;
		}
	}
	


}
