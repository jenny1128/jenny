package com.xxgl.sy.bean;

public class Items { //支出 和 预算
	private int id=0;
	
	private String date=null; //日期
	private float food=0; //餐饮
	private float clothes=0; //服饰
	private float cosmetic=0; //化妆品
	private float transport=0; //交通
	private float communicate=0; //通信
	private float education=0; //教育
	private float leisure=0; //娱乐休闲
	private float others=0; //其他
	private int type=0; //类型区分:支出 或者 预算
	private float sum=0; //总和
	
	
	public void setSum() {
		this.sum= food+ clothes+ cosmetic+ transport+ communicate+ education+ leisure+ others;
	}
	public float getSum(){
		return sum;
	}
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public float getFood() {
		return food;
	}
	public void setFood(float food) {
		this.food = food;
	}
	public float getClothes() {
		return clothes;
	}
	public void setClothes(float clothes) {
		this.clothes = clothes;
	}
	public float getCosmetic() {
		return cosmetic;
	}
	public void setCosmetic(float cosmetic) {
		this.cosmetic = cosmetic;
	}
	public float getTransport() {
		return transport;
	}
	public void setTransport(float transport) {
		this.transport = transport;
	}
	public float getCommunicate() {
		return communicate;
	}
	public void setCommunicate(float communicate) {
		this.communicate = communicate;
	}
	public float getEducation() {
		return education;
	}
	public void setEducation(float education) {
		this.education = education;
	}
	public float getLeisure() {
		return leisure;
	}
	public void setLeisure(float leisure) {
		this.leisure = leisure;
	}
	public float getOthers() {
		return others;
	}
	public void setOthers(float others) {
		this.others = others;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	
	

}
