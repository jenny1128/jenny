package com.xxgl.sy.bean;

public class Income { //收入统计
	
	private int id; //id
	private String date; //日期
	private float salary; //工资
	private float parttime_job;//兼职
	private float subsidy;//津贴
	private float otherincome;//其他
	private float sum; //总和
	
	public void setSum() {
		this.sum= salary+ parttime_job+subsidy+otherincome;
	}
	public float getSum(){
		return sum;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public float getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}
	public float getParttime_job() {
		return parttime_job;
	}
	public void setParttime_job(float parttime_job) {
		this.parttime_job = parttime_job;
	}
	public float getSubsidy() {
		return subsidy;
	}
	public void setSubsidy(float subsidy) {
		this.subsidy = subsidy;
	}
	public float getOtherincome() {
		return otherincome;
	}
	public void setOtherincome(float otherincome) {
		this.otherincome = otherincome;
	}
}
