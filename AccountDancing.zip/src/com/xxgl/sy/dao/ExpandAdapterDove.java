package com.xxgl.sy.dao;

import java.util.ArrayList;
import java.util.List;

import com.xxgl.sy.bean.Income;
import com.xxgl.sy.bean.Items;

import android.content.Context;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ExpandableListView.OnChildClickListener;

public class ExpandAdapterDove extends BaseExpandableListAdapter {
	
	private List<Items> listItems = new ArrayList<Items>() ;
	private List<Income> listIncome = new ArrayList<Income>() ;
	
		//list=budgetdao.showall();

	private String[] sum =null ;
	private String[][] detail = null;  
	private Context context=null;
	
	TextView getTextView() {
		AbsListView.LayoutParams lp = new AbsListView.LayoutParams(
				ViewGroup.LayoutParams.MATCH_PARENT, 55);
		// textView = new TextView(ShowListActivity.this);
		TextView textView = new TextView(this.context);
		textView.setLayoutParams(lp);
		textView.setGravity(Gravity.CENTER_VERTICAL);
		textView.setPadding(50, 0, 0, 0);
		textView.setTextSize(20);
		textView.setTextColor(Color.BLACK);
		return textView;
	}


	
    @Override
    public int getGroupCount() {
        return sum.length;
    }

    @Override
    public Object getGroup(int groupPosition) {
        return sum[groupPosition];
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public int getChildrenCount(int groupPosition) {
        return detail[groupPosition].length;
    }

    @Override
    public Object getChild(int groupPosition, int childPosition) {
        return detail[groupPosition][childPosition];
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return childPosition;
    }

    @Override
    public boolean hasStableIds() {
        return true;
    }

    @Override
    public View getGroupView(int groupPosition, boolean isExpanded,
            View convertView, ViewGroup parent) {
        LinearLayout ll = new LinearLayout(this.context);
        ll.setOrientation(0);
        TextView textView = getTextView();
        textView.setTextColor(Color.BLACK);
        textView.setText(getGroup(groupPosition).toString());
        ll.addView(textView);

        return ll;
    }

    @Override
    public View getChildView(int groupPosition, int childPosition,
            boolean isLastChild, View convertView, ViewGroup parent) {
        LinearLayout ll = new LinearLayout(this.context);
        ll.setOrientation(0);
        TextView textView = getTextView();
        textView.setText(getChild(groupPosition, childPosition).toString());
        ll.addView(textView);
        return ll;
    }

    @Override
    public boolean isChildSelectable(int groupPosition,int childPosition) {
        return true;
    }

}



