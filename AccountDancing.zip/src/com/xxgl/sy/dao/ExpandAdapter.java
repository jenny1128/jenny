package com.xxgl.sy.dao;

import java.util.ArrayList;
import java.util.List;

import com.xxgl.lxx.R;
import com.xxgl.sy.bean.Income;
import com.xxgl.sy.bean.Items;

import android.content.Context;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ExpandableListView.OnChildClickListener;

public class ExpandAdapter extends BaseExpandableListAdapter {
	private List list = new ArrayList();// 从库查的
	// 变量统一在构造函数中初始化
	private String[] sum = null;// 跟list一样大小
	private String[][] detail = null;
	private Context context = null;
	public ExpandAdapter(Context context, List list) {
		super();
		this.context = context;
		this.list = list;
		if (list != null && list.size() > 0) {
			sum = new String[list.size()];// 跟list一样大小
			detail = new String[list.size()][];
			transferList();
		} else
			return;
	}
	public void transferList() {
		for (int i = 0; i < list.size(); i++) {
			Object o = list.get(i);
			if (o instanceof Items) {
				Items item = (Items) o;
				String s = item.getDate() + "    " + item.getSum();
				sum[i] = s;
				detail[i] = transferChildConsume(item);
			} else if (o instanceof Income) {
				Income income = (Income) o;
				String s = income.getDate() + "    " + income.getSum();
				sum[i] = s;
				detail[i] = transferChildIncome(income);
			}
		}
	}
	public String[] transferChildIncome(Income income) {
		int childCount = 4;
		String name[] = { context.getString(R.string.type1), context.getString(R.string.type2), 
				context.getString(R.string.type3), context.getString(R.string.type4) };
		float[] in = { 0, 0, 0, 0 };
		List<String> s = new ArrayList<String>();
		in[0] = income.getSalary();
		in[1] = income.getParttime_job();
		in[2] = income.getSubsidy();
		in[3] = income.getOtherincome();
		for (int i = 0; i < childCount; i++) {
			if (in[i] > 0) {
				s.add(name[i] + in[i]);
			}
		}
		String[] ss = new String[s.size()];
		for (int i = 0; i < s.size(); i++) {
			ss[i] = s.get(i);
		}
		return ss;
	}

	public String[] transferChildConsume(Items item) {

		String name[] = { context.getString(R.string.type5),context.getString(R.string.type6), context.getString(R.string.type7)
				, context.getString(R.string.type8), context.getString(R.string.type9),context.getString(R.string.type10),context.getString(R.string.type11),
				context.getString(R.string.type12)};
		int childCount = 8;
		float values[] = { 0, 0, 0, 0, 0, 0, 0, 0 };
		values[0] = item.getFood();
		values[1] = item.getClothes();
		values[2] = item.getCosmetic();
		values[3] = item.getCommunicate();
		values[4] = item.getTransport();
		values[5] = item.getLeisure();
		values[6] = item.getEducation();
		values[7] = item.getOthers();
		List<String> s = new ArrayList<String>();
		for (int i = 0; i < childCount; i++) {
			if (values[i] > 0) {
				s.add(name[i] + values[i]);
			}
		}
		String[] ss = new String[s.size()];
		for (int i = 0; i < s.size(); i++) {
			ss[i] = s.get(i);
		}
		return ss;
	}

	TextView getTextView() {
		AbsListView.LayoutParams lp = new AbsListView.LayoutParams(
				ViewGroup.LayoutParams.MATCH_PARENT, 60);
		// textView = new TextView(ShowListActivity.this);
		TextView textView = new TextView(this.context);
		textView.setLayoutParams(lp);
		textView.setGravity(Gravity.CENTER_VERTICAL);
		textView.setPadding(60, 0, 0, 0);
		textView.setTextSize(20);
		textView.setTextColor(Color.BLACK);
		return textView;
	}

	@Override
	public int getGroupCount() {
		return sum.length;
	}

	@Override
	public Object getGroup(int groupPosition) {
		return sum[groupPosition];
	}

	@Override
	public long getGroupId(int groupPosition) {
		return groupPosition;
	}

	@Override
	public int getChildrenCount(int groupPosition) {
		return detail[groupPosition].length;
	}

	@Override
	public Object getChild(int groupPosition, int childPosition) {
		return detail[groupPosition][childPosition];
	}

	@Override
	public long getChildId(int groupPosition, int childPosition) {
		return childPosition;
	}

	@Override
	public boolean hasStableIds() {
		return true;
	}

	@Override
	public View getGroupView(int groupPosition, boolean isExpanded,
			View convertView, ViewGroup parent) {
		LinearLayout ll = new LinearLayout(this.context);
		ll.setOrientation(0);
		TextView textView = getTextView();
		textView.setTextColor(Color.BLACK);
		textView.setText(getGroup(groupPosition).toString());
		ll.addView(textView);

		return ll;
	}

	@Override
	public View getChildView(int groupPosition, int childPosition,
			boolean isLastChild, View convertView, ViewGroup parent) {
		LinearLayout ll = new LinearLayout(this.context);
		ll.setOrientation(0);
		TextView textView = getTextView();
		textView.setText(getChild(groupPosition, childPosition).toString());
		ll.addView(textView);
		return ll;
	}

	@Override
	public boolean isChildSelectable(int groupPosition, int childPosition) {
		return true;
	}

}
