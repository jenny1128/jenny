package com.xxgl.sy.dao;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import com.xxgl.sy.bean.Items;
import com.xxgl.sy.dateop.DateOp;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class ItemsDao { // 数据库操作对象

	private CreateDB createdb;

	public ItemsDao(Context context) {
		this.createdb = new CreateDB(context);
	}

	public void add(Items item) { //添加一条数据

		SQLiteDatabase db = createdb.getWritableDatabase();
		String sql = "insert into t_items(date,food,clothes,cosmetic,transport,communicate,education,leisure,others,type,sum) "
				+ "values (?,?,?,?,?,?,?,?,?,?,?)";
		db.execSQL(
				sql,
				new Object[] { item.getDate(), item.getFood(),
						item.getClothes(), item.getCosmetic(),
						item.getTransport(), item.getCommunicate(),
						item.getEducation(), item.getLeisure(),
						item.getOthers(), item.getType(), item.getSum() });
		db.close();

	}

	public void update(Items item, String date, int type) { //更新

		SQLiteDatabase db = createdb.getWritableDatabase();
		String sql = "update t_items set food=?,clothes=?,cosmetic=?,transport=?,"
				+ "communicate=?,education=?,leisure=?,others=?,sum=? "
				+ " where date=? and type=?";
		db.execSQL(
				sql,
				new Object[] { item.getFood(), item.getClothes(),
						item.getCosmetic(), item.getTransport(),
						item.getCommunicate(), item.getEducation(),
						item.getLeisure(), item.getOthers(), item.getSum(),
						date, type });
		db.close();

	}

	/**
	 * @return
	 */
	public List<Items> showall(int type) {
		List<Items> list = new ArrayList<Items>();

		SQLiteDatabase db = createdb.getReadableDatabase();
		String sql = "select * from t_items where type=" + type + " order by date desc  limit 9";
		Cursor cur = db.rawQuery(sql, new String[] {});

		// Log.d("BudgetDao", "-----------------------showall");
		// Log.d("BudgetDao", cur.getCount() + "");

		while (cur.moveToNext()) {
			Items item = new Items();
			// try {
			//
			// } catch (Exception e) {
			// e.printStackTrace();
			// }
			item.setId(cur.getInt(0));
			item.setDate(cur.getString(1));
			item.setFood(cur.getFloat(2));
			item.setClothes(cur.getFloat(3));
			item.setCosmetic(cur.getFloat(4));
			item.setCommunicate(cur.getFloat(5));
			item.setTransport(cur.getFloat(6));
			item.setLeisure(cur.getFloat(7));
			item.setEducation(cur.getFloat(8));
			item.setOthers(cur.getFloat(9));
			item.setSum();

			list.add(item);
			// System.out.println("从数据库取到的日期----------------------------------------"+
			// item.getDate());

		}

		cur.close();
		db.close();
		return list;
	}

	public List<Items> findsome(int type, String startdate, String enddate) {
		List<Items> list = new ArrayList<Items>();

		SQLiteDatabase db = createdb.getReadableDatabase();
		String sql = "select * from t_items where type=" + type
				+ " and date between '" + startdate + "'and  '" + enddate + "'";
		Cursor cur = db.rawQuery(sql, new String[] {});
		System.out.println("----------------------------------------"
				+ cur.getCount());

		while (cur.moveToNext()) {
			Items item = new Items();
			item.setId(cur.getInt(0));
			item.setDate(cur.getString(1));
			item.setFood(cur.getFloat(2));
			item.setClothes(cur.getFloat(3));
			item.setCosmetic(cur.getFloat(4));
			item.setCommunicate(cur.getFloat(5));
			item.setTransport(cur.getFloat(6));
			item.setLeisure(cur.getFloat(7));
			item.setEducation(cur.getFloat(8));
			item.setOthers(cur.getFloat(9));
			item.setSum();
			list.add(item);

		}
		cur.close();
		db.close();
		return list;
	}
	
	
	

	/*
	 * 返回一个数组，数组第一项是预算统计，第二项是消费统计，第三项是按收入统计
	 */

	public float[] findMonthData() {
		float[] count = { 0, 0, 0 };
		final Calendar currentDate = Calendar.getInstance();
		int mYear = currentDate.get(Calendar.YEAR);
		int mMonth = currentDate.get(Calendar.MONTH);
		int days = DateOp.LeapYear(mYear, mMonth);
		String date = (new StringBuilder().append(mYear).append("-")
				.append((mMonth + 1) > 9 ? (mMonth + 1) : "0" + (mMonth + 1))
				.append("-").append("01")).toString();
		
		SQLiteDatabase db = createdb.getReadableDatabase();
		
		// 查找本月预算总额
		String sql = "select sum(sum) from t_items where date like ? and type = ? ";
		Cursor cur = db.rawQuery(sql, new String[] {
				date.substring(0, 7) + "%", 1 + "" });
		
		if (cur.moveToNext()) {
			count[0] = cur.getFloat(0);
						
		}
		cur.close();

		
		// 查找本月消费总额
		String sql1 = "select sum(sum) from t_items where date like ? and type = ? ";
		Cursor cur1 = db.rawQuery(sql1, new String[] {
				date.substring(0, 7) + "%", 2 + "" });
		if (cur1.moveToNext()) {
			count[1] = cur1.getFloat(0);
		}

		cur1.close();
		
		// 查找本月收入总额
		String sql2 = "select sum(sum) from t_income where date like ?  ";
		Cursor cur2 = db.rawQuery(sql2, new String[] {
				date.substring(0, 7) + "%"});
		if (cur2.moveToNext()) {
			count[2] = cur2.getFloat(0);
//			System.out.println("收入---------------------------------------------"+count[2]);
//			System.out.println("收入---------------------------------------------"+cur2.getFloat(0));

		}
		
		cur2.close();
		db.close();
		return count;
	}
	/**
	 * 每天只能添加一条消费记录，此函数用于消费查重
	 * @param date 传入日期
	 * @return日期是否重复
	 */

	public boolean findConsumeSameDate(String date) {

		SQLiteDatabase db = createdb.getReadableDatabase();
		// 消费查重
		boolean IsSame = false;
		String sql = "select count(*) from t_items where date=? and type=? ";
		Cursor cur = db.rawQuery(sql, new String[] { date, 2 + "" });
		if (cur.moveToFirst() && cur.getInt(0) > 0) {
			IsSame = true;
		}
		cur.close();
		db.close();
		return IsSame;
	}

	public boolean findBudgetSameDate(String date) {

		SQLiteDatabase db = createdb.getReadableDatabase();
		// 消费查重
		boolean IsSame = false;
		String sql = "select count(*) from t_items where date like ? and type = ? ";
		Cursor cur = db.rawQuery(sql, new String[] {
				date.substring(0, 7) + "%", 1 + "" });
		if (cur.moveToFirst() && cur.getInt(0) > 0) {
			IsSame = true;
		}
		cur.close();
		db.close();
		return IsSame;
	}

	public Items search(String date, int type) {
		Items item = new Items();
		SQLiteDatabase db = createdb.getReadableDatabase();
		if (type == 2) {
			String sql = "select * from t_items where date=? and type=? ";
			Cursor cur = db.rawQuery(sql, new String[] { date, type + "" });
			if (cur.moveToNext()) {
				item.setFood(cur.getFloat(2));
				item.setClothes(cur.getFloat(3));
				item.setCosmetic(cur.getFloat(4));
				item.setTransport(cur.getFloat(5));
				item.setCommunicate(cur.getFloat(6));
				item.setEducation(cur.getFloat(7));
				item.setLeisure(cur.getFloat(8));
				item.setOthers(cur.getFloat(9));

			}
			cur.close();
		} else {
			String sql = "select * from t_items where date like ? and type=? ";
			Cursor cur = db.rawQuery(sql, new String[] {
					date.substring(0, 6) + "%", type + "" });
			if (cur.moveToNext()) {
				item.setFood(cur.getFloat(2));
				item.setClothes(cur.getFloat(3));
				item.setCosmetic(cur.getFloat(4));
				item.setTransport(cur.getFloat(5));
				item.setCommunicate(cur.getFloat(6));
				item.setEducation(cur.getFloat(7));
				item.setLeisure(cur.getFloat(8));
				item.setOthers(cur.getFloat(9));
			}
			cur.close();

		}

		db.close();

		return item;
	}

	/**
	 * 查找本月消费各项
	 * 
	 * @return消费各项
	 */

	public float[] getConsumeItems() {
		float[] allItems = { 0, 0, 0, 0, 0, 0, 0, 0 };
		final Calendar currentDate = Calendar.getInstance();
		int mYear = currentDate.get(Calendar.YEAR);
		int mMonth = currentDate.get(Calendar.MONTH);
		int days = DateOp.LeapYear(mYear, mMonth);
		String startdate = (new StringBuilder().append(mYear).append("-")
				.append((mMonth + 1) > 9 ? (mMonth + 1) : "0" + (mMonth + 1))
				.append("-").append("01")).toString();
		String enddate = (new StringBuilder().append(mYear).append("-")
				.append((mMonth + 1) > 9 ? (mMonth + 1) : "0" + (mMonth + 1))
				.append("-").append("" + days)).toString();
		;
		SQLiteDatabase db = createdb.getReadableDatabase();
		String sql = "select sum(food),sum(clothes),sum(cosmetic),sum(transport),"
				+ "sum(communicate),sum(education),sum(leisure),sum(others) "
				+ "from t_items where type=2 "
				+ "and date between '"
				+ startdate + "'and  '" + enddate + "'";
		Cursor cur = db.rawQuery(sql, new String[] {});
		if (cur.moveToNext()) {
			for (int i = 0; i < 8; i++) {
				allItems[i] = cur.getFloat(i);
			}
		}
		db.close();
		cur.close();
		return allItems;
	}

	/**
	 * 查找本月预算各项
	 * 
	 * @return预算各项
	 */

	public float[] getBudgetItems() {
		float[] allItems = { 0, 0, 0, 0, 0, 0, 0, 0 };
		final Calendar currentDate = Calendar.getInstance();
		int mYear = currentDate.get(Calendar.YEAR);
		int mMonth = currentDate.get(Calendar.MONTH);
		String subdate = (new StringBuilder().append(mYear).append("-")
				.append((mMonth + 1) > 9 ? (mMonth + 1) : "0" + (mMonth + 1)))
				.toString();

		SQLiteDatabase db = createdb.getReadableDatabase();
		String sql = "select sum(food),sum(clothes),sum(cosmetic),sum(transport),"
				+ "sum(communicate),sum(education),sum(leisure),sum(others) "
				+ "from t_items where type=1 " + "and substr(date,1,7)=? ";
		Cursor cur = db.rawQuery(sql, new String[] { subdate });
		if (cur.moveToNext()) {
			for (int i = 0; i < 8; i++) {
				allItems[i] = cur.getFloat(i);
			}
		}
		db.close();
		cur.close();
		return allItems;
	}
}
