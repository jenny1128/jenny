package com.xxgl.sy.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;

public class CreateDB extends SQLiteOpenHelper {

	public CreateDB(Context context) {
		super(context,"accountDB", null, 1);// 默认保存在包下的datebase文件夹下
		// TODO Auto-generated constructor stub
	}

	@Override
	public void onCreate(SQLiteDatabase db) {// 在数据库每一次被创建的时候调用的
		// TODO Auto-generated method stub
		
	
		 String items_sql="CREATE TABLE t_items (id integer primary key autoincrement, date varchar(20) ," +
		 		" food NUMERIC DEFAULT ( 0.0 )," +
		 		" clothes NUMERIC DEFAULT ( 0.0 )," +
		 		" cosmetic NUMERIC DEFAULT ( 0.0 )," +
		 		" transport NUMERIC DEFAULT ( 0.0 )," +
		 		" communicate NUMERIC DEFAULT ( 0.0 )," +
		 		" education NUMERIC DEFAULT ( 0.0 )," +
		 		"leisure NUMERIC DEFAULT ( 0.0 ),"+
		 		"others NUMERIC DEFAULT ( 0.0 ),"+
		 		"type integer, " +
		 		"sum NUMERIC DEFAULT ( 0.0 ))"; 
		 
		 String income_sql="CREATE TABLE t_income (id integer primary key autoincrement, date varchar(20) ," +
			 		" salary NUMERIC DEFAULT ( 0.0 )," +
			 		" parttime_job DEFAULT ( 0.0 )," +
			 		"subsidy NUMERIC DEFAULT ( 0.0 ),"+
			 		"otherincome NUMERIC DEFAULT ( 0.0 ),"+
			 		"sum NUMERIC DEFAULT ( 0.0 ))"; 
		 
		 db.execSQL(items_sql);		
		 db.execSQL(income_sql); 
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {// 此方法在版本号改变的时候被调用

	}



	
}
