package com.xxgl.sy.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.xxgl.sy.bean.Income;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class IncomeDao {

	private CreateDB createdb;

	public IncomeDao(Context context) {
		this.createdb = new CreateDB(context);
	}

	public void add(Income income) {
		
		SQLiteDatabase db = createdb.getWritableDatabase();
		String sql = "insert into t_income(date,salary,parttime_job,subsidy,otherincome,sum) "
				+ "values (?,?,?,?,?,?)";
		db.execSQL(	sql,new Object[] { income.getDate(), income.getSalary(),
						income.getParttime_job(), income.getSubsidy(),
						income.getOtherincome(),income.getSum()});
		db.close();

	}
	
	public boolean findSameDate(String date)
	{
		SQLiteDatabase db = createdb.getReadableDatabase();
		Boolean IsSame = false;
		String sql = "select count(*) from t_income where date=?  ";
		Cursor cur = db.rawQuery(sql, new String[] { date });

		if (cur.moveToFirst() && cur.getInt(0) > 0) {
			IsSame = true;
		}
		cur.close();
		db.close();
		return IsSame;
	}
	
	public Income search(String date )
	 {
		Income income = new Income();
		SQLiteDatabase db = createdb.getReadableDatabase();

		String sql = "select * from t_income where date =?";
		Cursor cur = db.rawQuery(sql, new String[] { date });
		if (cur.moveToNext()) {
//			income = new Income();
			income.setSalary(cur.getFloat(2));
			income.setParttime_job(cur.getFloat(3));
			income.setSubsidy(cur.getFloat(4));
			income.setOtherincome(cur.getFloat(5));
			
			System.out.println("gongzi cur------------------------------------------"+cur.getFloat(2));
			System.out.println("gongzi income------------------------------------------"+income.getSalary());
		}
		cur.close();
		db.close();

		return income;
	 }
	
	
	
	
	

	/**
	 * @return
	 */
	public List<Map<String,Object>> showall1() {
		
		List<Map<String,Object>> list = new ArrayList<Map<String,Object>>();
		
		SQLiteDatabase db = createdb.getReadableDatabase();
		String sql = "select * from t_income order by date desc  limit 10 ";
		Cursor cur = db.rawQuery(sql, new String[] {});
		

		while (cur.moveToNext()) {
			
			Map<String,Object>  hashmap = new HashMap<String,Object>(); 
			//hashmap.put("id", cur.getInt(0));
			hashmap.put("date", cur.getString(1));
			hashmap.put("salary", cur.getFloat(2));
			hashmap.put("parttime_job", cur.getFloat(3));
			hashmap.put("subsidy", cur.getFloat(4));
			hashmap.put("otherincome", cur.getFloat(5));					
		    list.add(hashmap);

		}

        cur.close();
		db.close();
		return list;
	}
	
public List<Income> showall() {
		
		List<Income> list = new ArrayList<Income>();
		
		SQLiteDatabase db = createdb.getReadableDatabase();
		String sql = "select * from t_income order by date desc  limit 10 ";
		Cursor cur = db.rawQuery(sql, new String[] {});
		

		while (cur.moveToNext()) {
			Income income=new Income();
			income.setDate(cur.getString(1));			
			income.setSalary( cur.getFloat(2));
			income.setParttime_job( cur.getFloat(3));
			income.setSubsidy( cur.getFloat(4));
			income.setOtherincome( cur.getFloat(5));	
			list.add(income);   

		}

        cur.close();
		db.close();
		return list;
	}
	

	public void update(Income income, String date) {

		SQLiteDatabase db = createdb.getWritableDatabase();
		String sql = "update t_income set salary=?,parttime_job=?,subsidy=?,otherincome=?,"
				+ "sum=? "
				+ " where date=? ";
		db.execSQL(
				sql,
				new Object[] { income.getSalary(), income.getParttime_job(),
						income.getSubsidy(), income.getOtherincome(), income.getSum(),	date});
		db.close();

	}

	public List<Income> findsome(String startdate, String enddate) {
		List<Income> list = new ArrayList<Income>();

		SQLiteDatabase db = createdb.getReadableDatabase();
		String sql = "select * from t_income where  date between '" + startdate + "'and  '" + enddate + "'";
		Cursor cur = db.rawQuery(sql, new String[] {});
		System.out.println("----------------------------------------"
				+ cur.getCount());

		while (cur.moveToNext()) {
			Income income = new Income();
			income.setId(cur.getInt(0));
			income.setDate(cur.getString(1));
			income.setSalary(cur.getFloat(2));
			income.setParttime_job(cur.getFloat(3));
			income.setSubsidy(cur.getFloat(4));
			income.setOtherincome(cur.getFloat(5));
		
			income.setSum();
			list.add(income);

		}
		cur.close();
		db.close();
		return list;
	}
	
	
	
	
	
	
	
	

	
	
	
	

}
