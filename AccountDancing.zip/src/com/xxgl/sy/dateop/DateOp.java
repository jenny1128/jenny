package com.xxgl.sy.dateop;

import java.util.Calendar;

public class DateOp {
	
	public static String getCurrentDate() //获取当前日期
	{ 
		 int  mYear=Calendar.getInstance().get(Calendar.YEAR);
		 int  mMonth=Calendar.getInstance().get(Calendar.MONTH);
		 int  mDay=Calendar.getInstance().get(Calendar.DAY_OF_MONTH);
		
	    StringBuilder  date=(new StringBuilder()).append(mYear).append("-")
				.append((mMonth+1) > 9 ? (mMonth + 1) : "0" + (mMonth + 1)).append("-")
				.append(mDay > 9 ? mDay : "0" + mDay);
	    return date.toString();		
	}
	
	public static String getCurrentMonth() //获取年月
	{
		int  mYear=Calendar.getInstance().get(Calendar.YEAR);
		int  mMonth=Calendar.getInstance().get(Calendar.MONTH);

	    StringBuilder date=(new StringBuilder()).append(mYear).append("-").append((mMonth+1) > 9 ? (mMonth + 1) : "0" + (mMonth + 1));
	    return date.toString();		
	}
	
	
	public static int LeapYear(int year,int month) //获取某年某月的天数
	{
		int days=0;
		switch(month)
		{
		case 1:
		case 3:
		case 5:
		case 7:
		case 8:
		case 10:
		case 12:days=31;break;
		case 4:
		case 6:
		case 9:
		case 11:days=30;break;
		case 2:if((year%4==0&&year%100!=0)||(year%400==0)){days=29;}
		       else{days=28;}break;
		}
		return days;
	}
	

}
